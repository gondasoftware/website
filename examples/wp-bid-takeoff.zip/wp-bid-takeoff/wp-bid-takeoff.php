<?php
/*
 * Plugin Name: WP Bid Takeoff
 * Description: Embeds a bid takeoff application iframe with save/load functionality for all users.
 * Version: 1.1
 * Author: Your Name
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Bid_Takeoff {

    public function __construct() {
        add_shortcode('wp_bid_takeoff', [$this, 'render_iframe_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_wp_bid_takeoff_save', [$this, 'handle_save_data']);
        add_action('wp_ajax_wp_bid_takeoff_load', [$this, 'handle_load_data']);
        add_action('wp_ajax_nopriv_wp_bid_takeoff_load', [$this, 'handle_load_data']); // Allow non-logged-in users to load
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);

        add_action('init', [$this, 'bid_text_block_register']);
    }

    function bid_text_block_register() {
        // Register the block script
        wp_register_script(
            'bid-text-block-script',
            plugins_url('/js/block.js', __FILE__),
            array('wp-blocks', 'wp-element', 'wp-editor'), // Dependencies
            filemtime(plugin_dir_path(__FILE__) . 'js/block.js') // Version based on file time
        );
    
        // Register the block type
        register_block_type('bid-text-block/bid', array(
            'editor_script' => 'bid-text-block-script',
        ));
    }

    public function render_iframe_shortcode($atts) {
        $atts = shortcode_atts([
            'width' => '100%',
            'height' => '500px',
            'embed' => '1',
            'savebtn' => '1',
            'loadbtn' => '1',
            'embedsavebtn' => '1',
            'embedloadbtn' => '1',
            'newprojectbtn' => '1',
            'editable' => '1',
            'file' => 'wpbidtakeoff.data'
        ], $atts, 'wp_bid_takeoff');

        $instance_id = uniqid('wpbidtakeoff_');
        $file_path = $atts['file'];

        $output = '<div data-instance-id="' . esc_attr($instance_id) . '" data-file-path="' . esc_attr($file_path) . '">';
        $output .= '<iframe id="' . esc_attr($instance_id) . '" class="wp-iframe" src="https://gondasoftware.eu/bid/' 
            . '?embed=' . esc_attr($atts['embed']) 
            . '&saveBtn=' . esc_attr($atts['savebtn']) 
            . '&loadBtn=' . esc_attr($atts['loadbtn']) 
            . '&embedSaveBtn=' . esc_attr($atts['embedsavebtn']) 
            . '&embedLoadBtn=' . esc_attr($atts['embedloadbtn'])
            . '&newProjectBtn=' . esc_attr($atts['newprojectbtn']) 
            . '&editable=' . esc_attr($atts['editable']) 
            . '" width="' . esc_attr($atts['width']) 
            . '" height="' . esc_attr($atts['height']) . '" frameborder="0"></iframe>';
        $output .= '</div>';

        return $output;
    }

    public function enqueue_scripts() {
        wp_enqueue_script(
            'wp-bid-takeoff-js',
            plugins_url('/js/wp-bid-takeoff.js', __FILE__),
            [],
            '1.1',
            true
        );
        wp_localize_script(
            'wp-bid-takeoff-js',
            'wpBidTakeoff',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wp_bid_takeoff_nonce')
            ]
        );
    }

    public function handle_save_data() {
        check_ajax_referer('wp_bid_takeoff_nonce', 'nonce');

        // Restrict saving to logged-in users with edit capability (optional)
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['error' => 'Permission denied']);
        }

        $instance_id = sanitize_text_field($_POST['instance_id']);
        $file_path = sanitize_text_field($_POST['file_path']);
        $blob_data = $_FILES['blob_data'];

        if (!$blob_data || !$file_path) {
            wp_send_json_error(['error' => 'Missing data']);
        }

        $upload_dir = wp_upload_dir();
        $target_dir = $upload_dir['basedir'] . '/wp-bid-takeoff/';
        if (!file_exists($target_dir)) {
            wp_mkdir_p($target_dir); // Create directory if it doesn’t exist
            file_put_contents($target_dir . '.htaccess', "Options -Indexes\n"); // Prevent directory listing
        }

        $target_path = $target_dir . $file_path;

        if (move_uploaded_file($blob_data['tmp_name'], $target_path)) {
            // Set file permissions to be readable by all (e.g., 0644)
            //chmod($target_path, 0644);
            wp_send_json_success(['message' => 'File saved successfully']);
        } else {
            wp_send_json_error(['error' => 'Failed to save file']);
        }
    }

    public function handle_load_data() {
        // No nonce check for loading to allow public access (adjust as needed)
        //check_ajax_referer('wp_bid_takeoff_nonce', 'nonce');

        $file_path = sanitize_text_field($_POST['file_path']);
        $upload_dir = wp_upload_dir();
        $full_path = $upload_dir['basedir'] . '/wp-bid-takeoff/' . $file_path;

        if (file_exists($full_path)) {
            $file_content = file_get_contents($full_path);
            wp_send_json_success(['blob_data' => base64_encode($file_content)]);
        } else {
            wp_send_json_error(['error' => 'File not found']);
        }
    }

    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'post.php' && $hook !== 'post-new.php') return;
        wp_enqueue_script(
            'wp-bid-takeoff-admin-js',
            plugins_url('/js/wp-bid-takeoff-admin.js', __FILE__),
            ['jquery'],
            '1.1',
            true
        );
    }

}

new WP_Bid_Takeoff();