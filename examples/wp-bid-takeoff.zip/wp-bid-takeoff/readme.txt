https://gondasoftware.eu/bid/?embed=1&saveBtn=0&loadBtn=0&embedSaveBtn=0&embedLoadBtn=1&newProjectBtn=0&editable=0&

[wpbidtakeoff file="bid.data"  width="100%" height="500px" embed="1" savebtn="1" loadbtn="1" embedsavebtn="1" embedloadbtn="1" newprojectbtn="1" editable="1"]

php.ini  (128M)
upload_max_filesize = 128M
post_max_size = 128M

.htaccess (for Apache servers):
php_value upload_max_filesize 128M
php_value post_max_size 128M

Gutenberg Block Editor vs. Classic Editor