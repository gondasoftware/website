// Frontend script for iframe communication
function createNewTakeoff(instanceID) {
    let iframe = document.getElementById(instanceID);
    if (!iframe) return;

    const message = {
        stringData: "parent-->child___create_a_new_project",
        blobData: null
    };
    iframe.contentWindow.postMessage(message, "*");
}

function saveData(blobData, instanceID) {
    let container = document.querySelector(`[data-instance-id="${instanceID}"]`);
    if (!container) return;
    let filePath = container.getAttribute("data-file-path");

    const formData = new FormData();
    formData.append("action", "wp_bid_takeoff_save");
    formData.append("nonce", wpBidTakeoff.nonce);
    formData.append("instance_id", instanceID);
    formData.append("file_path", filePath);
    formData.append("blob_data", blobData, "takeoff.data");

    fetch(wpBidTakeoff.ajax_url, {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Takeoff saved successfully!");
        } else {
            alert("Save failed: " + data.data.error);
        }
    })
    .catch(error => console.error("Save Error:", error));
}

function loadData(instanceID) {
    let container = document.querySelector(`[data-instance-id="${instanceID}"]`);
    if (!container) return;
    let filePath = container.getAttribute("data-file-path");
    let iframe = document.getElementById(instanceID);
    if (!iframe) return;

    const formData = new FormData();
    formData.append("action", "wp_bid_takeoff_load");
    formData.append("nonce", wpBidTakeoff.nonce);
    formData.append("file_path", filePath);

    fetch(wpBidTakeoff.ajax_url, {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const blob = base64ToBlob(data.data.blob_data);
            const message = {
                stringData: "parent-->child___load_this_data",
                blobData: blob
            };
            iframe.contentWindow.postMessage(message, "*");
        } else {
            createNewTakeoff(instanceID); // Fallback to new project if no file
        }
    })
    .catch(error => console.error("Load Error:", error));
}

// Helper to convert base64 to Blob
function base64ToBlob(base64) {
    const byteString = atob(base64);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const uint8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
        uint8Array[i] = byteString.charCodeAt(i);
    }
    return new Blob([arrayBuffer]);
}

// Message listener
window.addEventListener("message", function(event) {
    try {
        let action = event.data.action;
        let blobData = event.data.blobData;

        let iframes = document.querySelectorAll(".wp-iframe");
        let senderIframe = Array.from(iframes).find(iframe => iframe.contentWindow === event.source);
        if (!senderIframe) return;

        let instanceID = senderIframe.id;
        if (!instanceID || !instanceID.startsWith("wpbidtakeoff_")) return;

        if (action === "child-->parent___save_this_data") {
            saveData(blobData, instanceID);
        } else if (action === "child-->parent___dom_content_loaded_in_child" || action === "child-->parent___send_me_the_data_to_load") {
            loadData(instanceID);
        }
    } catch (error) {
        console.error("Error processing message:", error);
    }
}, false);