// TinyMCE plugin for adding shortcode
(function() {
    tinymce.PluginManager.add('wp_bid_takeoff', function(editor, url) {
        editor.addButton('wp_bid_takeoff_button', {
            title: 'Add Bid Takeoff',
            image: url.replace('/js', '/images') + '/bid.png',
            onclick: function() {
                const timestamp = new Date().toISOString().replace(/[:T]/g, '-').split('.')[0] + '-' + String(Date.now() % 1000).padStart(3, '0');
                const shortcode = `[wp_bid_takeoff width="100%" height="500px" embed="1" savebtn="1" loadbtn="1" embedsavebtn="1" embedloadbtn="1" newprojectbtn="1" editable="1" file="wpbidtakeoff_${timestamp}.data"]`;
                editor.insertContent(shortcode);
            }
        });
    });
})();