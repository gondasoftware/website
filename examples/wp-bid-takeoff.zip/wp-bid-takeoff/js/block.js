wp.blocks.registerBlockType('bid-text-block/bid', {
    title: 'BID Takeoff Embed',
    icon: 'welcome-view-site',
    category: 'text',

    // Define block attributes
    attributes: {
        fileName: {
            type: 'string',
            default: '',
        },
        width: {
            type: 'string',
            default: '100%',
        },
        height: {
            type: 'string',
            default: '500px',
        },
        embed: {
            type: 'string',
            default: '1', // Default to "1" (enabled)
        },
        savebtn: {
            type: 'string',
            default: '1',
        },
        loadbtn: {
            type: 'string',
            default: '1',
        },
        embedsavebtn: {
            type: 'string',
            default: '1',
        },
        embedloadbtn: {
            type: 'string',
            default: '1',
        },
        newprojectbtn: {
            type: 'string',
            default: '1',
        },
        editable: {
            type: 'string',
            default: '1',
        },
    },

    // Edit function: What users see and interact with in the editor
    edit: function(props) {
        const { attributes, setAttributes } = props;
        const {
            fileName,
            width,
            height,
            embed,
            savebtn,
            loadbtn,
            embedsavebtn,
            embedloadbtn,
            newprojectbtn,
            editable,
        } = attributes;

        // Generate a default filename if not already set
        if (!fileName) {
            const currentTime = new Date().toISOString().replace(/[-:T.]/g, '').split('Z')[0];
            setAttributes({ fileName: `${currentTime}.data` });
        }

        // Return the editor UI
        return [
            // Inspector Controls (Sidebar settings)
            wp.element.createElement(
                wp.blockEditor.InspectorControls,
                {},
                wp.element.createElement(
                    wp.components.PanelBody,
                    { title: 'Embed Settings', initialOpen: true },
                    // Width input
                    wp.element.createElement(
                        wp.components.TextControl,
                        {
                            label: 'Width',
                            value: width,
                            onChange: (newWidth) => setAttributes({ width: newWidth }),
                        }
                    ),
                    // Height input
                    wp.element.createElement(
                        wp.components.TextControl,
                        {
                            label: 'Height',
                            value: height,
                            onChange: (newHeight) => setAttributes({ height: newHeight }),
                        }
                    ),
                    // File name display (read-only)
                    wp.element.createElement(
                        wp.components.TextControl,
                        {
                            label: 'File Name',
                            value: fileName,
                            readOnly: true,
                        }
                    ),
                    // Toggle for embed
                    wp.element.createElement(
                        wp.components.ToggleControl,
                        {
                            label: 'Embed',
                            checked: embed === '1',
                            onChange: (newValue) => setAttributes({ embed: newValue ? '1' : '0' }),
                        }
                    ),
                    // Toggle for savebtn
                    wp.element.createElement(
                        wp.components.ToggleControl,
                        {
                            label: 'Save Button',
                            checked: savebtn === '1',
                            onChange: (newValue) => setAttributes({ savebtn: newValue ? '1' : '0' }),
                        }
                    ),
                    // Toggle for loadbtn
                    wp.element.createElement(
                        wp.components.ToggleControl,
                        {
                            label: 'Load Button',
                            checked: loadbtn === '1',
                            onChange: (newValue) => setAttributes({ loadbtn: newValue ? '1' : '0' }),
                        }
                    ),
                    // Toggle for embedsavebtn
                    wp.element.createElement(
                        wp.components.ToggleControl,
                        {
                            label: 'Embed Save Button',
                            checked: embedsavebtn === '1',
                            onChange: (newValue) => setAttributes({ embedsavebtn: newValue ? '1' : '0' }),
                        }
                    ),
                    // Toggle for embedloadbtn
                    wp.element.createElement(
                        wp.components.ToggleControl,
                        {
                            label: 'Embed Load Button',
                            checked: embedloadbtn === '1',
                            onChange: (newValue) => setAttributes({ embedloadbtn: newValue ? '1' : '0' }),
                        }
                    ),
                    // Toggle for newprojectbtn
                    wp.element.createElement(
                        wp.components.ToggleControl,
                        {
                            label: 'New Project Button',
                            checked: newprojectbtn === '1',
                            onChange: (newValue) => setAttributes({ newprojectbtn: newValue ? '1' : '0' }),
                        }
                    ),
                    // Toggle for editable
                    wp.element.createElement(
                        wp.components.ToggleControl,
                        {
                            label: 'Editable',
                            checked: editable === '1',
                            onChange: (newValue) => setAttributes({ editable: newValue ? '1' : '0' }),
                        }
                    )
                )
            ),

            // Main editor content
            wp.element.createElement(
                'div',
                { className: 'bid-takeoff-block-editor' },
                'BID Takeoff Embed',
                wp.element.createElement(
                    'p',
                    null,
                    `Shortcode: [wp_bid_takeoff file="${fileName}" width="${width}" height="${height}" embed="${embed}" savebtn="${savebtn}" loadbtn="${loadbtn}" embedsavebtn="${embedsavebtn}" embedloadbtn="${embedloadbtn}" newprojectbtn="${newprojectbtn}" editable="${editable}"]`
                )
            ),
        ];
    },

    // Save function: What gets saved to the database/front-end
    save: function(props) {
        const { attributes } = props;
        const {
            fileName,
            width,
            height,
            embed,
            savebtn,
            loadbtn,
            embedsavebtn,
            embedloadbtn,
            newprojectbtn,
            editable,
        } = attributes;

        // Use the stored filename, or generate a new one if missing
        const finalFileName = fileName || `${new Date().toISOString().replace(/[-:T.]/g, '').split('Z')[0]}.data`;

        return `[wp_bid_takeoff file="${finalFileName}" width="${width}" height="${height}" embed="${embed}" savebtn="${savebtn}" loadbtn="${loadbtn}" embedsavebtn="${embedsavebtn}" embedloadbtn="${embedloadbtn}" newprojectbtn="${newprojectbtn}" editable="${editable}"]`;
    },
});