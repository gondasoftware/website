<?php

if (!defined('DOKU_INC')) die();
