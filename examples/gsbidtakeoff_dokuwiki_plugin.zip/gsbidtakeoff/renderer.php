<?php

if (!defined('DOKU_INC')) die();

require_once DOKU_PLUGIN . 'gsbidtakeoff/global.php';

class renderer_plugin_gsbidtakeoff extends Doku_Renderer_xhtml
{

    function canRender($format) {
        return ($format=='xhtml');
    }

    function reset() {
        $this->doc = '';
        $this->footnotes = array();
        $this->lastsec = 0;
        $this->store = '';
        $this->_counter = array();
    }

/*
    function cdata($text) {
        $this->doc .= $text;
    }
*/

}