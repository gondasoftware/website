<?php

if (!defined('DOKU_INC')) die();

require_once DOKU_PLUGIN . 'gsbidtakeoff/global.php';

class syntax_plugin_gsbidtakeoff_gsbidtakeoff extends DokuWiki_Syntax_Plugin
{
    public function getType()
    {
        return 'protected';
    }

    public function getPType()
    {
        return 'block';
    }

    public function getSort()
    {
        return 1;
    }

    public function connectTo($mode)
    {
        if ($this->getConf('bid takeoff on off') === 0) {
            return;
        }

        $this->Lexer->addSpecialPattern('\nBID Takeoff parameters:.*?\{\{:dokuwiki:gsbidtakeoff:[^\}]+?\}\}', $mode, 'plugin_gsbidtakeoff_'.$this->getPluginComponent());
    }

    public function handle($match, $state, $pos, Doku_Handler $handler)
    {
        if ($state === DOKU_LEXER_SPECIAL) {

            //BID Takeoff parameters: width=100% height=500px embed=1 saveBtn=1 loadBtn=1 embedSaveBtn=1 embedLoadBtn=1 newProjectBtn=1 editable=1
            preg_match_all('/(\w+)=([\w%]+)/', $match, $matches);
            $keyValuePairs = array_combine($matches[1], $matches[2]);

            preg_match('/(\{\{:dokuwiki:gsbidtakeoff:[^\}]+?\}\})/', $match, $matches);

            return array(
                'state' => 'special',
                'wikiLink' => $matches[1],
                'keyValuePairs' => $keyValuePairs
            );
        }
        return array();
    }

    public function render($mode, Doku_Renderer $renderer, $data)
    {
        if ($mode !== 'xhtml') return false;

        if ($data['state'] === 'special') {

            $keyValuePairs = $data['keyValuePairs'];
            $wikiLink = $data['wikiLink'];
            $instanceID = uniqid('gsbidtakeoff_'); // Generate unique ID for each Draw.io instance

            $urlParams = "?";
            foreach ($keyValuePairs as $key => $value) {
                if(!str_contains($key, 'width') && !str_contains($key, 'height')){
                    $urlParams .= $key . '=' . $value . '&';
                }
            }

            $renderer->doc .= '
                <div class="gs-drawio-container" data-instance-id="' . $instanceID . '" data-wiki-link="' . $wikiLink . '">

                    <iframe id="' . $instanceID . '" 
                    width="' . (($keyValuePairs['width'] === null) ? '100%' : $keyValuePairs['width'])  . '"
                    height="' . (($keyValuePairs['height'] === null) ? '500px' : $keyValuePairs['height'])  . '"
                    class="gs-iframe" 
                    src="' . $this->getConf('bid takeoff src') . $urlParams . '" frameborder="0"></iframe>

                </div>';
        }

        return true;
    }
}