<?php

if (!defined('DOKU_INC')) die();

function myDebugLog($message)
{
    $logFile = DOKU_INC . '/data/debug.log'; // Save log in DokuWiki's data directory
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND);
}

function mySanitizeString($input) {
    // Convert the string to lowercase
    $lowercaseString = strtolower($input);
    
    // Replace underscores with spaces
    $sanitizedString = str_replace('_', ' ', $lowercaseString);
    
    return $sanitizedString;
}

function myIsNullOrEmptyString($str)
{
    return $str === null || trim($str) === '';
}

function replaceTheFirst($originalText, $replaceThisText, $replaceWithThisText){
    
    $pos = strpos($originalText, $replaceThisText);

    if ($pos !== false) {
        $newText = substr_replace($originalText, $replaceWithThisText, $pos, strlen($replaceThisText));
        return $newText;
    }
    return $originalText;
}

function matchRegex($text, $regexPattern){
    preg_match($regexPattern, $text, $matches);

    if($matches){
        return true;
    }else{
        return false;
    }
}

