<?php

if (!defined('DOKU_INC')) {
    define('DOKU_INC', realpath(__DIR__ . '/../../') . '/');
}
if (!defined('DOKU_PLUGIN')) {
    define('DOKU_PLUGIN', DOKU_INC . 'lib/plugins/');
}

require_once DOKU_PLUGIN . 'gsbidtakeoff/global.php';

require_once DOKU_INC . 'inc/common.php';
require_once DOKU_INC . 'inc/auth.php';


class action_plugin_gsbidtakeoff_gsbidtakeoff extends DokuWiki_Action_Plugin {

    public function register(Doku_Event_Handler $controller)
    {
        $controller->register_hook('TPL_METAHEADER_OUTPUT', 'BEFORE', $this, 'injectJS');
        $controller->register_hook('AJAX_CALL_UNKNOWN', 'BEFORE', $this, 'handleUpload');
        $controller->register_hook('AJAX_CALL_UNKNOWN', 'BEFORE', $this, 'handleDownload');
        $controller->register_hook('AJAX_CALL_UNKNOWN', 'BEFORE', $this, 'checkExist');
    }

    public function injectJS(&$event, $param)
    {
        $event->data['script'][] = [
            'type' => 'text/javascript',
            'charset' => 'utf-8',
            '_data' => file_get_contents(DOKU_PLUGIN . 'gsbidtakeoff/js/gs/gsbidtakeoff.js')
        ];
    }

    public function checkExist(Doku_Event $event, $param)
    {
        if ($event->data !== 'plugin_gsbidtakeoff_gsbidtakeoff_checkexist') {
            return;
        }

        $event->preventDefault();
        $event->stopPropagation();

        header('Content-Type: application/json');

        $wikiLink = $_POST['wikiLink'];
        // {{:dokuwiki:gsbidtakeoff:gsbidtakeoff.data}}
        $mediaID = trim($wikiLink, '{}:');
        // dokuwiki:gsbidtakeoff:gsbidtakeoff.data
        $filePath = mediaFN($mediaID);

        if (file_exists($filePath)) {
            echo json_encode(["success" => true, "exist" => true]);
        }else{
            echo json_encode(["success" => true, "exist" => false]);
        }

    }

    public function handleUpload(Doku_Event $event, $param)
    {
        if ($event->data !== 'plugin_gsbidtakeoff_gsbidtakeoff_upload') {
            return;
        }

        $event->preventDefault();
        $event->stopPropagation();
        
        header('Content-Type: application/json');

        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(["success" => false, "error" => "File upload error."]);
            return;
        }

        if (!auth_ismanager() && !auth_quickaclcheck('upload') >= AUTH_EDIT) {
            echo json_encode(["success" => false, "error" => "Permission denied."]);
            return;
        }
;
        $wikiLink = $_POST['wikiLink'];
        // {{:dokuwiki:gsbidtakeoff:gsbidtakeoff.data}}
        $mediaID = trim($wikiLink, '{}:');
        // dokuwiki:gsbidtakeoff:gsbidtakeoff.data
        $filePath = mediaFN($mediaID);
        // C:/gf/DokuWikiStick/dokuwiki/dokuwiki/data/media/dokuwiki/gsbidtakeoff/gsbidtakeoff.data
        $filename = basename($filePath);
        // gsbidtakeoff.data
        // Sanitize filename
        //$filename = cleanID($filename);
        $fileDir = dirname($filePath);
        // C:/gf/DokuWikiStick/dokuwiki/dokuwiki/data/media/dokuwiki/gsbidtakeoff

        if (!is_dir($fileDir)) {
            mkdir($fileDir, 0775, true);
        }

        // Move uploaded file
        if (move_uploaded_file($_FILES['file']['tmp_name'], $filePath)) {
            myDebugLog('ok');
            echo json_encode(["success" => true, "url" => $wikiLink]);
        } else {
            myDebugLog('error');
            echo json_encode(["success" => false, "error" => "Could not move file."]);
        }
    }

    public function handleDownload(Doku_Event $event, $param)
    {
        if ($event->data !== 'plugin_gsbidtakeoff_gsbidtakeoff_download') {
            return;
        }

        $event->preventDefault();
        $event->stopPropagation();

        header('Content-Type: application/json');

        if (!isset($_POST['wikiLink'])) {
            echo json_encode(["success" => false, "error" => "No file path provided."]);
            return;
        }

        if (!auth_ismanager() && !auth_quickaclcheck('upload') >= AUTH_EDIT) {
            echo json_encode(["success" => false, "error" => "Permission denied."]);
            return;
        }

        // Get the full file path from the request
        $wikiLink = $_POST['wikiLink'];
        // {{:dokuwiki:gsbidtakeoff:gsbidtakeoff.data}}
        $mediaID = trim($wikiLink, '{}:');
        // dokuwiki:gsbidtakeoff:gsbidtakeoff.data
        $filePath = mediaFN($mediaID);
        // C:/gf/DokuWikiStick/dokuwiki/dokuwiki/data/media/dokuwiki/gsbidtakeoff/gsbidtakeoff.data
        $filename = basename($filePath);
        // gsbidtakeoff.data
        // Sanitize filename
        //$filename = cleanID($filename);
        $fileDir = dirname($filePath);
        // C:/gf/DokuWikiStick/dokuwiki/dokuwiki/data/media/dokuwiki/gsbidtakeoff

        if (!file_exists($filePath)) {
            //echo json_encode(["success" => false, "error" => "File not found."]);
            // Create the file if it doesn't exist
            file_put_contents($filePath, '');
            return;
        }

        header('Content-Type: application/xml');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        readfile($filePath);
        exit;
    }
}