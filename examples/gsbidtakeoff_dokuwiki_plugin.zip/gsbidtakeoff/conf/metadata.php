<?php

$meta['bid takeoff src'] = array('string');
$meta['bid takeoff on off'] = array('onoff');
