<?php

$conf['bid takeoff src'] = 'https://gondasoftware.eu/bid/';
$conf['bid takeoff on off'] = 1;