function createNewTakeoff(instanceID) {

    let iframe = document.getElementById(instanceID);
    if (!iframe) return;

    const message = {
        stringData: "parent-->child___create_a_new_project",
        blobData: null
    };

    iframe.contentWindow.postMessage(message, "*");

}

function saveData(blobData, instanceID) {

    let container = document.querySelector(`[data-instance-id="${instanceID}"]`);
    if (!container) return;
    let wikiLink = container.getAttribute("data-wiki-link");

    const formData = new FormData();
    formData.append("file", blobData, "takeoff.data");
    formData.append("wikiLink", wikiLink);

    fetch(DOKU_BASE + "lib/exe/ajax.php?call=plugin_gsbidtakeoff_gsbidtakeoff_upload", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Takeoff saved successfully!");
        } else {
            alert("Upload failed: " + data.error);
        }
    })
    .catch(error => console.error("Upload Error:", error));
}

function openSavedTakeoff(instanceID) {

    let container = document.querySelector(`[data-instance-id="${instanceID}"]`);
    if (!container) return;
    let wikiLink = container.getAttribute("data-wiki-link");
    let iframe = document.getElementById(instanceID);
    if (!iframe) return;

    const formData = new FormData();
    formData.append("wikiLink", wikiLink);

    fetch(DOKU_BASE + "lib/exe/ajax.php?call=plugin_gsbidtakeoff_gsbidtakeoff_checkexist", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.exist) {

            loadTheExisting(instanceID);
            
        } else {

            createNewTakeoff(instanceID);
            
        }
    })
    .catch(error => console.error("Upload Error:", error));

    
}

function loadTheExisting(instanceID){

    let container = document.querySelector(`[data-instance-id="${instanceID}"]`);
    if (!container) return;
    let wikiLink = container.getAttribute("data-wiki-link");
    let iframe = document.getElementById(instanceID);
    if (!iframe) return;

    const formData = new FormData();
    formData.append("wikiLink", wikiLink);

    fetch(DOKU_BASE + "lib/exe/ajax.php?call=plugin_gsbidtakeoff_gsbidtakeoff_download", {
        method: "POST",
        body: formData,
        headers: {
            "X-Requested-With": "XMLHttpRequest"
        }
    })
    .then(response => response.blob())
    .then(blob => {

        const message = {
            stringData: "parent-->child___load_this_data",
            blobData: blob
        };

        iframe.contentWindow.postMessage(message, "*");

    })
    .catch(error => {
        console.error("Error downloading takeoff:", error);
    });

}

window.addEventListener("message", function(event) {
/*
    if ( 
        !(
            event.origin.includes("gsbidtakeoff.eu/bid/")
            || event.origin.includes("localhost")
            || event.origin.includes("192.168.0.18")
        )
    ) return;
*/
    try {

        let action;
        let blobData;
        try {
            action = event.data.action;
            blobData = event.data.blobData;
        } catch (error) {
            return;
        }

        let iframes = document.querySelectorAll(".gs-iframe");

        let senderIframe = Array.from(iframes).find(iframe => iframe.contentWindow === event.source);
        if (!senderIframe) return;

        let instanceID = senderIframe.id;

        if(instanceID === null || !instanceID.startsWith("gsbidtakeoff_")) return;

        if (action === "child-->parent___save_this_data") {
            saveData(blobData, instanceID);
        }else if(action === "child-->parent___dom_content_loaded_in_child"){
            openSavedTakeoff(instanceID);
        }else if(action === "child-->parent___send_me_the_data_to_load"){
            openSavedTakeoff(instanceID);
        }

    } catch (error) {
        console.error("Error processing message:", error);
    }
}, false);

//----------------------------------------------------------


document.addEventListener("DOMContentLoaded", function () {

    const textarea = document.getElementById("wiki__text");

    if (!textarea) return;

    const gsbidtakeoffButtonId = "gsbidtakeoffButtonId";

    window.toolbar.push({
        type: 'insert',
                title: 'Add DID takeoff tag',
                icon: DOKU_BASE + 'lib/plugins/gsbidtakeoff/images/bid.png',
                insert: '',
                sample: '',
                block: false,
                post: '',
                key: '',
                class: gsbidtakeoffButtonId,
                id: gsbidtakeoffButtonId
    });
    setTimeout(() => {

        const button = document.querySelector('.' + gsbidtakeoffButtonId);
        if (button) {
            //button.innerHTML = "&#128218;";
            button.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();

                insertAtCursor("BID Takeoff parameters: width=100% height=500px embed=1 saveBtn=1 loadBtn=1 embedSaveBtn=1 embedLoadBtn=1 newProjectBtn=1 editable=1\n{{:dokuwiki:gsbidtakeoff:" + getFormatedTimestamp() + ".data}}");

            });
        }
    }, 100);

    function insertAtCursor(addText) {

        const start = textarea.selectionStart;
        const text = textarea.value;

        // Insert the tag at the cursor position
        textarea.value = text.substring(0, start) + addText + text.substring(start);

        // Move the cursor to after the inserted tag
        textarea.selectionStart = textarea.selectionEnd = start + addText.length;

        // Focus back on the textarea
        textarea.focus();
    }

    // 2025-01-30_14-32-12_960
    function getFormatedTimestamp() {
        const d = new Date();
        const date = d.toISOString().split('T')[0];
        const time = d.toTimeString().split(' ')[0].replace(/:/g, '-');
        const ms = d.getMilliseconds().toString().padStart(3, '0'); // Ensures 3-digit milliseconds
        return `${date}_${time}_${ms}`;
    }

});